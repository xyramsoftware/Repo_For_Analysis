import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { CloudinaryOptions, CloudinaryUploader } from 'ng2-cloudinary';
import { ToastrService } from 'toastr-ng2';
import { cloudinarUpload } from '../../../../cloudinary.config';
import { CouponsService } from '../coupons.service';

@Component({
  selector: 'app-edit-coupon',
  templateUrl: './edit-coupon.component.html',
  styleUrls: ['./edit-coupon.component.scss'],
  providers: [CouponsService]
})
export class EditCouponComponent {
  CategoryType: any = 'Select'
  public expenseDetails: any = {};
  private couponId: any;
  public isLoading: boolean = false;
  public loading: boolean = false;
  selectcomponentdata: any = []
  selectdata: any = []
  movedcomponentdata: any = []
  comptoSelected: any = []
  removecomponentdata: any = []
  applyedtests: any = []
  Categorydata: any = []
  ExpenseData: any = {
    ExpenseItem: '',
    Date: '',
    InvoiceNo: '',
    RecorderBy: '',
    Amount: ''
  }

  constructor(
    private route: ActivatedRoute,
    public router: Router,
    public toastr: ToastrService,
    public couponService: CouponsService
  ) {
    this.route.params.map(params => params['id']).subscribe(Id => {
      if (Id != null) {
        this.couponId = Id;
        this.getexpenseDetailById(Id); //function call to get tagDetail by id
      }
    });
  }

  getexpenseDetailById(Id) {
    this.couponService.getExpenseById(Id).subscribe(response => {
      this.expenseDetails = response;
      this.ExpenseData.Date = response.Date
      //this.couponDetails.Date = response.Date;
      console.log(this.expenseDetails);
      this.comptoSelected = this.expenseDetails.test
      console.log(this.comptoSelected)
      console.log(response);
      // this.getalltestdata()
    });


  }

 
  onSubExpense(form: NgForm) {
    this.isLoading = !this.isLoading;
    console.log(this.comptoSelected)

    this.expenseDetails.test = this.comptoSelected
    console.log(this.expenseDetails)
    console.log(this.ExpenseData)
    this.couponService.updateexpenseById(this.expenseDetails, this.couponId)
      .subscribe(
        response => {
          console.log(response)
          this.toastr.success('Expense' + '  "' + response.ExpenseItem + '"  ' + '  Updated Successfully!', 'Success!');
          this.isLoading = !this.isLoading;
          this.router.navigate(['/coupons/all']);
        },
        error => {
          this.isLoading = !this.isLoading;
          this.toastr.error('Error....');
          // this.router.navigate(['/coupons/all']);
        }
      );
  }
  cancel() {
    this.router.navigate(['/coupons/all']);
  }


  dateChanged(newDate) {
    this.expenseDetails.Date = new Date(newDate);
    console.log(this.expenseDetails.Date); // <-- for testing
  }

  onChangeResource(categotyType, event) {
    console.log(categotyType)
    console.log(event.target.value)
    this.loading = !this.loading;
    //console.log(event)
    this.couponService.getCategoryTestData(categotyType).subscribe(data => {
      console.log(data)
      this.selectdata = data
      for (let i = 0; i < this.selectdata.length; i++) {
        this.selectdata[i]['selectedcomp'] = false
        this.selectdata[i]['removedcomp'] = false
      }
      this.selectcomponentdata = this.selectdata
      console.log(this.selectcomponentdata)
      this.loading = !this.loading;
    })

  }
}
