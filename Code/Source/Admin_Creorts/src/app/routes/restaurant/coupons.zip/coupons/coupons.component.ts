import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'toastr-ng2';
import { CouponsService } from './coupons.service';
import { NgForm } from '@angular/forms';

const swal = require('sweetalert');

@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.scss'],
  providers: [CouponsService]
})
export class CouponsComponent {
  public coupons: Array<any>;
  public loading: boolean = true;
  //public items: any[] = [];
  expense: any = [];
  Fields: any = {}
  displayedit: boolean = false
  selectedScreen: any = 0
  selectedScreen1: any
  selectedFieldType: any = 0
  selectedFieldType1: any
  displayfielsOption: boolean = false
  displayFileOption: boolean = false
  clientid: any
  items: Array<any>;
  private totalAmount = 0;
  displaypriority: boolean = false

  FiledsList: any = []

  allfieldsdata: any = []
  dropdownSettings = {};
  selectedQrCodeFields: any = []
  selectedItems = [];
  QrcodeDataGet: any[]
  displayQRCodeedit: boolean = false
  selectedImageType1: any
  constructor(
    public router: Router,
    public toastr: ToastrService,
    public couponsService: CouponsService
  ) {
    this.getExpenseDetail();
  }
  expenseEdit(key) {
    console.log(key);
    this.router.navigate(['/coupons/editCoupon', key]);
  }
  viewexpense(key) {
    this.router.navigate(['/coupons/viewCoupon', key]);
  }

  getExpenseDetail() {
    this.couponsService.getFormFiledsData().subscribe(
      response => {
        // response.reverse();
        this.FiledsList = response
        this.items = response
        for (let j = 0; j < this.FiledsList.length; j++) {
          this.totalAmount += this.items[j].Amount
        }

        console.log(this.items)
        console.log(this.totalAmount);
        this.coupons = response;
        console.log(this.coupons)
        this.loading = !this.loading;
      },
      error => {
        this.loading = !this.loading;
        this.toastr.error('Somthing is going wrong', 'Please login again');
      }
    );
  }

  // couponDelete(key: any, i: any) {
  //   swal(
  //     {
  //       title: 'Are you sure?',
  //       text: 'You will not be able to recover this data!',
  //       type: 'warning',
  //       showCancelButton: true,
  //       confirmButtonColor: '#DD6B55',
  //       confirmButtonText: 'Yes, delete it!',
  //       cancelButtonText: 'No, cancel!',
  //       closeOnConfirm: false,
  //       closeOnCancel: false
  //     },
  //     isConfirm => {
  //       if (isConfirm) {
  //         this.couponsService.deleteCouponById(key).subscribe(response => {
  //           for (let i = 0; i < this.expense.length; i++) {
  //             if (this.expense[i]._id == key) {
  //               this.expense.splice(i, 1)
  //             }
  //           }
  //           //this.coupons.splice(i, 1);
  //           swal('Deleted!', 'Coupons Deleted Successfully!', 'success');
  //         });
  //       } else {
  //         swal('Cancelled', 'Your data is safe :)', 'error');
  //       }
  //     }
  //   );
  // }




  ExpenseDelete(key: any, i: any) {
    console.log(key, i)
    swal({
      title: 'Are you sure?',
      text: 'You will not be able to recover this data!',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#DD6B55',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      closeOnConfirm: false,
      closeOnCancel: false
    }, (isConfirm) => {
      if (isConfirm) {
        this.couponsService.deleteExpenseById(key)
          .subscribe(response => {
            this.items.splice(i, 1); 
            this.loading = !(this.loading);
            this.totalAmount=0;
            this.getExpenseDetail(); 
            swal('Deleted!', 'Deleted Successfully!', 'success');
          })
      } else {
        swal('Cancelled', 'Your data is safe :)', 'error');

      }
    })

  }


  onChangeTime(event) {

  }
}
