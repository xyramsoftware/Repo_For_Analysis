import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';
import { ConstantService } from '../../../constant.service';

@Injectable()
export class CouponsService {
  constructor(public http: Http, public constantService: ConstantService) {}

  //Geting Coupons Data
  getCouponsData() {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http
      .get(this.constantService.API_ENDPOINT + 'coupons', {
        headers: headers
      })
      .map((data: Response) => data.json())
      .catch(this.handleError);
  }
  getExpenseById(expenseid: any) {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    headers.append('Authorization', authToken);
    return this.http
      .get(this.constantService.API_ENDPOINT + 'expense/byId/' + expenseid, {
        headers: headers
      })
      .map((data: Response) => data.json())
      .catch(this.handleError);
  }

   //get Category List
   getCategoryData() {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    headers.append('Authorization', authToken);
    return this.http
      .get(this.constantService.API_ENDPOINT + 'categories', {
        headers: headers
      })
      .map((data: Response) => data.json())
      .catch(this.handleError);
  }

    //get Category test  List
    getCategoryTestData(CategoryName) {
      const headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let authToken = localStorage.getItem('token');
      headers.append('Authorization', authToken);
      return this.http
        .get(this.constantService.API_ENDPOINT + 'test/by/categoryCode?search='+CategoryName, {
          headers: headers
        })
        .map((data: Response) => data.json())
        .catch(this.handleError);
    }
  

  //Add New Coupon
  addCouponData(coupon: any) {
    const body = JSON.stringify(coupon);
    console.log(body);
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    headers.append('Authorization', authToken);
    return this.http
      .post(this.constantService.API_ENDPOINT + 'expense/create', body, {
        headers: headers
      })
      .map((data: Response) => data.json())
      .catch(this.handleError);
  }

  //Delete Coupons Bt Id
  deleteCouponById(couponId: any) {
    const headers = new Headers();
    let authToken = localStorage.getItem('token');
    headers.append('Authorization', authToken);
    return this.http
      .delete(this.constantService.API_ENDPOINT + 'expense/delete/' + couponId, {
        headers: headers
      })
      .map((data: Response) => data)
      .catch(this.handleError);
  }

 

  updateexpenseById(data, couponId: any) {
    const body = JSON.stringify(data);
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    headers.append('Authorization', authToken);
    return this.http
      .put(this.constantService.API_ENDPOINT + 'expense/update/' + couponId, body, {
        headers: headers
      })
      .map((data: Response) => data.json())
      .catch(this.handleError);
  }

   //getting AllCategory
   getTestData() {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    return this.http.get(this.constantService.API_ENDPOINT + 'test', {
      headers: headers
    })
      .map((data: Response) => data.json())
      .catch(this.handleError)
  }

   //Update Category By Its Id
   updateTestById(data, categoryId: any) {
    const body = JSON.stringify(data);
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    headers.append('Authorization', authToken);
    return this.http.put(this.constantService.API_ENDPOINT + 'test/' + categoryId, body, {
      headers: headers
    })
      .map((data: Response) => data.json())
      .catch(this.handleError)
  }
//////////////////////////////////////////////////////////////////
  getFormFiledsData() {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    let clientId = localStorage.getItem('id')
    headers.append('Authorization', authToken);
    return this.http.get(this.constantService.API_ENDPOINT + 'expense/all/', {
      headers: headers
    })
      .map((data: Response) => data.json())
      .catch(this.handleError)
  }

  addAccommodationPerson(data: any) {
    const body = JSON.stringify(data);
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    let clientid = localStorage.getItem('id')
    headers.append('Authorization', authToken);
    return this.http.post(this.constantService.API_ENDPOINT + 'pickupform/create/'+clientid, body, {
      headers: headers
    })
      .map((data: Response) => data.json())
      .catch(this.handleError)
  }

  deleteExpenseById(expenseId: any) {
    const headers = new Headers();
    let authToken = localStorage.getItem('token');
    let ClientId = localStorage.getItem('id')
    headers.append('Authorization', authToken);
    return this.http.delete(this.constantService.API_ENDPOINT + 'expense/delete/'+ expenseId, {
      headers: headers
    })
      .map((data: Response) => data)
      .catch(this.handleError)
  }

  updateRegFieldsById(data: any, Id: any) {
    const body = JSON.stringify(data);
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let authToken = localStorage.getItem('token');
    let clientId = localStorage.getItem('id')
    headers.append('Authorization', authToken);
    return this.http.put(this.constantService.API_ENDPOINT + 'pickupform/update/'+clientId+'/'+ Id, body, {
      headers: headers
    })
      .map((data: Response) => data.json())
      //.catch(this.handleError)
  }


  private handleError(error: any) {
    return Observable.throw(error.json());
  }
}
