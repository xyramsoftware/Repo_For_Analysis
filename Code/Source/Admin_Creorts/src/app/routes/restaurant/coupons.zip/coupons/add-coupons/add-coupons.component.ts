import { Component } from '@angular/core';
import { CloudinaryOptions, CloudinaryUploader } from 'ng2-cloudinary';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'toastr-ng2';
import { CouponsService } from '../coupons.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-add-coupons',
  templateUrl: './add-coupons.component.html',
  styleUrls: ['./add-coupons.component.scss'],
  providers: [CouponsService]
})
export class AddCouponsComponent {
  CategoryType:any='Select'
  CategoryTypedata:any
  public expense: any = {
    ExpenseItem: '',
    date: 0,
    InvoiceNo: '',
    RecorderBy: '',
    Amount: ''
     };
  Categorydata:any=[]
  public isLoading: boolean = false;
  selectcomponentdata:any=[]
  selectdata:any=[]
  movedcomponentdata:any=[]
  comptoSelected:any=[]
  removecomponentdata:any=[]
  public loading: boolean = false;
  constructor(
    public router: Router,
    public toastr: ToastrService,
    public couponsService: CouponsService,
    public datepipe: DatePipe
  ) {

    //this.getalltestdata()
    this.getcategorydata()
  }

  getalltestdata(){
    
         this.couponsService.getTestData().subscribe(testdata=>{
            this.selectdata = testdata
            for(let i=0;i<this.selectdata.length;i++){
              this.selectdata[i]['selectedcomp'] = false
              this.selectdata[i]['removedcomp'] = false
            }
           this.selectcomponentdata = this.selectdata
           console.log(this.selectcomponentdata)
    
         })
    
      }


      getcategorydata(){
        this.couponsService.getCategoryData().subscribe(data=>{
          this.Categorydata = data
          console.log(this.Categorydata)
        })
      }


  onSubCoupon(form: NgForm) {
    console.log(form);
    this.expense.ExpenseItem = form.value.expenseitem
    this.expense.date = form.value.date
   // this.expense.Date =this.datepipe.transform(form.value.date, 'yyyy-mm-dd')
    this.expense.InvoiceNo = form.value.invoiceno
    this.expense.RecorderBy=form.value.recorderby
    this.expense.Amount=form.value.amount
    this.isLoading = !this.isLoading;
    this.couponsService.addCouponData(this.expense).subscribe(
      response => {
        console.log("response")
        console.log(response)
        this.expense = response
        this.toastr.success('Expense'+'  "'+response.ExpenseItem+'"  '+'   Added Successfully!', 'Success!');
        this.isLoading = !this.isLoading;
        this.router.navigate(['/coupons/all']);
      },
      error => {
        this.isLoading = !this.isLoading;
        this.toastr.error('Error....');
        this.router.navigate(['/coupons/all']);
      }
    );
  }

  cancel() {
    this.router.navigate(['/coupons/all']);
  }


}
